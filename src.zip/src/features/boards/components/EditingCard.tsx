import type { Piece } from "@lichess-org/chessground/types";
import { Card, CloseButton, Divider } from "@mantine/core";
import { useContext } from "react";
import { useStore } from "zustand";
import FenInput from "@/components/panels/info/FenInput";
import { TreeStateContext } from "@/components/TreeStateContext";
import * as classes from "./EditingCard.css";
import PiecesGrid from "./PiecesGrid";

function EditingCard({
  boardRef,
  setEditingMode,
  selectedPiece,
  setSelectedPiece,
}: {
  boardRef: React.MutableRefObject<HTMLDivElement | null>;
  setEditingMode: (editing: boolean) => void;
  selectedPiece: Piece | null;
  setSelectedPiece: (piece: Piece | null) => void;
}) {
  const store = useContext(TreeStateContext)!;
  const fen = useStore(store, (s) => s.currentNode().fen);
  const headers = useStore(store, (s) => s.headers);
  const setFen = useStore(store, (s) => s.setFen);

  return (
    <Card shadow="md" style={{ position: "relative", overflow: "visible" }} className={classes.card}>
      <CloseButton style={{ position: "absolute", top: 10, right: 15 }} onClick={() => setEditingMode(false)} />
      <FenInput currentFen={fen} />
      <Divider my="md" />
      <PiecesGrid
        fen={fen}
        boardRef={boardRef}
        onPut={(newFen) => {
          setFen(newFen);
        }}
        orientation={headers.orientation}
        selectedPiece={selectedPiece}
        setSelectedPiece={setSelectedPiece}
      />
    </Card>
  );
}

export default EditingCard;
