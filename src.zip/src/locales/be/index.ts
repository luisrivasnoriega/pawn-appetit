import common from "./common.json";

const be = {
  language: {
    DisplayName: "Беларуская",
  },
  translation: common,
};

export default be;
