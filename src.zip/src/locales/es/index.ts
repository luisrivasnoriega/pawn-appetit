import common from "./common.json";

const es = {
  language: {
    DisplayName: "Español",
  },
  translation: common,
};

export default es;
