import common from "./common.json";

const nb = {
  language: {
    DisplayName: "Norsk bokmål",
  },
  translation: common,
};

export default nb;
