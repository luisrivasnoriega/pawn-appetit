import common from "./common.json";

const it = {
  language: {
    DisplayName: "Italiano",
  },
  translation: common,
};

export default it;
