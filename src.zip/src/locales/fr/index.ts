import common from "./common.json";

const fr = {
  language: {
    DisplayName: "Français",
  },
  translation: common,
};

export default fr;
