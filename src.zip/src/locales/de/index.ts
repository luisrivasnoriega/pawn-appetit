import common from "./common.json";

const de = {
  language: {
    DisplayName: "Deutsch",
  },
  translation: common,
};

export default de;
