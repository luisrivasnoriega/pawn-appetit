import common from "./common.json";

const pl = {
  language: {
    DisplayName: "Polski",
  },
  translation: common,
};

export default pl;
