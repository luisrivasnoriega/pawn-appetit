import common from "./common.json";

const en_US = {
  language: {
    DisplayName: "English (US)",
  },
  translation: common,
};

export default en_US;
