import common from "./common.json";

const pt = {
  language: {
    DisplayName: "Português",
  },
  translation: common,
};

export default pt;
