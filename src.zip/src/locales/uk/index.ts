import common from "./common.json";

const uk = {
  language: {
    DisplayName: "Українська",
  },
  translation: common,
};

export default uk;
