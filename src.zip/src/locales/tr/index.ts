import common from "./common.json";

const tr = {
  language: {
    DisplayName: "Türkçe",
  },
  translation: common,
};

export default tr;
