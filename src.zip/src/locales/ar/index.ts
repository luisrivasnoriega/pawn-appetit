import common from "./common.json";

const ar = {
  language: {
    DisplayName: "العربية",
  },
  translation: common,
};

export default ar;
