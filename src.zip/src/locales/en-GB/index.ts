import common from "./common.json";

const en_GB = {
  language: {
    DisplayName: "English (UK)",
  },
  translation: common,
};

export default en_GB;
