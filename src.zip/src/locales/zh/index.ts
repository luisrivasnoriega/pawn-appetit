import common from "./common.json";

const zh = {
  language: {
    DisplayName: "中文 (简体)",
  },
  translation: common,
};

export default zh;
