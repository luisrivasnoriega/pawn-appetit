import common from "./common.json";

const ru = {
  language: {
    DisplayName: "Русский",
  },
  translation: common,
};

export default ru;
