import common from "./common.json";

const ja = {
  language: {
    DisplayName: "日本語",
  },
  translation: common,
};

export default ja;
