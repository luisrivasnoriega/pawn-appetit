import common from "./common.json";

const hy = {
  language: {
    DisplayName: "Հայերեն",
  },
  translation: common,
};

export default hy;
