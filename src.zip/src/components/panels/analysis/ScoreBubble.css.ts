import { style } from "@vanilla-extract/css";

export const label = style({
  textOverflow: "clip",
});
